#ifndef FILESYSTEM_VOSONG_H
#define FILESYSTEM_VOSONG_H

#include <string>
#include <vector>

/*


Author: Song Vo

Date : 2/20/24


Description: Defines File and file manager in stupidos namespace. Its a basic file system
*/



namespace stupidos {

    class File {
    private:
        std::string filename;
        std::string contents;

    public:
        // Constructor
        File(const std::string& name, const std::string& contents);

        // Getter methods
        std::string getFileName() const;
        std::string getFileContents() const;
        int fileSize() const;
    };

    class FileManager {
    private:
        std::vector<File> files;

    public:
        // Constructor
        FileManager();

        // Destructor
        ~FileManager();

        // Methods
        void addFile(const std::string& name, const std::string& contents);
        void deleteFile(const std::string& name);
        std::string readFile(const std::string& name) const;
        std::vector<std::string> getFileNames() const;
        File findFileByName(const std::string& name) const;
    };

} // namespace stupidos

#endif // FILESYSTEM_VOSONG_H
