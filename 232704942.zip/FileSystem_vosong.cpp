#include "FileSystem_vosong.h"
/*
Author: Song Vo
Date : 2/20/24
 Description : Defines a file class with prop of names and contents, file maanager that manages multiple file objects alloing adding and deleting
 */
namespace stupidos {

    // Implementation for the File class

    File::File(const std::string& name, const std::string& contents)
        : filename(name), contents(contents) {}

    std::string File::getFileName() const {
        return filename;
    }

    std::string File::getFileContents() const {
        return contents;
    }

    int File::fileSize() const {
        return contents.size();
    }

    // Implementation for the FileManager class

    stupidos::FileManager::FileManager() {}

    stupidos::FileManager::~FileManager() {}

    void FileManager::addFile(const std::string& name, const std::string& contents) {
        files.push_back(File(name, contents));
    }

    void FileManager::deleteFile(const std::string& name) {
        for (auto it = files.begin(); it != files.end(); ++it) {
            if (it->getFileName() == name) {
                files.erase(it);
                break;
            }
        }
    }

    std::string FileManager::readFile(const std::string& name) const {
        for (const auto& file : files) {
            if (file.getFileName() == name) {
                return file.getFileContents();
            }
        }
        return "File not found";
    }

    std::vector<std::string> FileManager::getFileNames() const {
        std::vector<std::string> filenames;
        for (const auto& file : files) {
            filenames.push_back(file.getFileName());
        }
        return filenames;
    }

    File FileManager::findFileByName(const std::string& name) const {
        for (const auto& file : files) {
            if (file.getFileName() == name) {
                return file;
            }
        }
        // Return a default-constructed File if not found
        return File("", "");
    }

} // namespace stupidos
