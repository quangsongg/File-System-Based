#include <iostream>
#include <iomanip>
#include "FileSystem_vosong.h"
/*
Author: Song Vo

Date : 2/20/24
Description : simple file management system. Allow users to interact with the menu to perform tasks

*/

using namespace std;
using namespace stupidos;

void showMenu() {
    cout << "Menu:\n";
    cout << "1 - Show files on hard drive\n";
    cout << "2 - Add a file\n";
    cout << "3 - Delete a file\n";
    cout << "4 - Output a file\n";
    cout << "0 - Exit simulation\n";
}

//void displayFiles(const FileManager& fileManager) {
//    cout << "Filename                                          size\n";
//
//    for (const auto& filename : fileManager.getFileNames()) {
//        const File& file = fileManager.findFileByName(filename);
//        cout << left << setw(40) << filename << right << setw(10) << file.fileSize() << " blk\n";
//    }
//}

int main() {
    FileManager fileManager;

    int choice;
    do {
        showMenu();


        cin >> choice;
        cin.ignore(); // Ignore newline character

        switch (choice) {
        case 1:
            cout << "Filename                                          size\n";

            for (const auto& filename : fileManager.getFileNames()) {
                const File& file = fileManager.findFileByName(filename);
                cout << left << setw(40) << filename << right << setw(10) << file.fileSize() << " blk\n";
            }
            break;
        case 2: {
            string filename, contents;
            cout << "Enter filename: ";
            //tline(cin, filename);
            cin >> filename;
            cout << "Enter content string: ";
            //getline(cin, contents);
            cin >> contents;
            fileManager.addFile(filename, contents);

            break;
        }
        case 3: {
            string filename;
            cout << "Enter filename: ";
            cin >> filename;
            fileManager.deleteFile(filename);

            break;
        }
        case 4: {
            string filename, content;

            cout << "Enter filename: ";
            //getline(cin, filename);
            cin >> filename;
            
            for (const auto& filename : fileManager.getFileNames()) {
                const File& file = fileManager.findFileByName(filename);
                cout << "Filename                      Contents" << endl;
                cout << left << setw(30) << filename << right << file.getFileContents() << endl;
            }
            break;
        }
        case 0:

            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 0);

    return 0;
}
