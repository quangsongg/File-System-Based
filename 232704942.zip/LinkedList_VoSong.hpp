//Author: Song Vo
//
//Date : 2/20/24
//

//Description: defines template Node and Link list. Provides basic operation for the link list, like adding the nodes in
#include <iostream>
using namespace std;

namespace stupidos
{
    template <typename T>
    class Node
    {
    public:
        //Properties
        T data;
        Node<T> *next;

        //Constructor
        Node() : data(NULL), next(NULL){};
        Node(T x) : data(x), next(NULL){};

        //Functions
        void setData(T data);
        T getData();
        void setNext(Node<T> *node);
        Node<T> getNext();
    };

    template <typename T>
    class LinkedList
    {
    public:
        //Properties
        stupidos::Node<T> *head;
        stupidos::Node<T> *tail;
        int size;

        //Constructor
        LinkedList() : head(NULL), tail(NULL), size(0){};

        //Functions
        void addToList(T data);
        void printList();
    };
};

//Implement Functions

template <typename T>
void stupidos::Node<T>::setData(T data)
{
    this->data = data;
}

template <typename T>
T stupidos::Node<T>::getData()
{
    return this->data;
}

template <typename T>
void stupidos::Node<T>::setNext(Node<T> *node)
{
    this->next = node;
}

template <typename T>
stupidos::Node<T> stupidos::Node<T>::getNext()
{
    return this->next;
}

template <typename T>
void stupidos::LinkedList<T>::addToList(T data)
{
    //Making a newNode
    stupidos::Node<T> *newNode = new stupidos::Node<T>(data);

    //Check list is empty
    if (size == 0)
    {
        this->head = newNode;
        this->tail = newNode;
        this->head->next = tail;
        this->size++;
        return;
    }

    //Check list is not empty
    this->tail->next = newNode;
    this->tail = newNode;
    this->size++;
    delete newNode;
    return;
}

template <typename T>
void stupidos::LinkedList<T>::printList()
{
    stupidos::Node<T> *crossNode = this->head;

    while (crossNode->next != NULL)
    {
        cout << crossNode->data << endl;
        crossNode = crossNode->next;
    }
    cout << crossNode->data << endl;
}
