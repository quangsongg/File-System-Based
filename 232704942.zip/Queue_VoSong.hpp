#include <iostream>
#include <array>
/*

Author: Song Vo

Date : 2/20/24


Description: This code defines a template Queue, Provide basic operation for the data struc, add and remove
*/




#define MAX_SIZE 100
using namespace std;

namespace stupidos {
    template <typename T>
    class Queue {
    public:
        array<T, MAX_SIZE> items;
        int size;
        int frontIndex;
        int rearIndex;

    public:
        // Constructor
        Queue() : items(), size(0), frontIndex(0), rearIndex(0) {}

        // Destructor
        ~Queue() {}

        // Functions
        void enqueue(const T& item);
        T dequeue();
        T front() const;
        int getSize() const;
        void empty();
        bool isEmpty() const;
        void print() const;
    };

    // Implementations
    template <typename T>
    void Queue<T>::enqueue(const T& item) {
        if (size == MAX_SIZE) {
            cout << "Queue is full. Cannot enqueue more items.\n";
            return;
        }
        items[rearIndex] = item;
        rearIndex = (rearIndex + 1) % MAX_SIZE;
        ++size;
    }

    template <typename T>
    T Queue<T>::dequeue() {
        if (isEmpty()) {
            throw out_of_range("Queue is empty");
        }
        T item = items[frontIndex];
        frontIndex = (frontIndex + 1) % MAX_SIZE;
        --size;
        return item;
    }

    template <typename T>
    T Queue<T>::front() const {
        if (isEmpty()) {
            cout << "Queue is empty. No front element.\n";
            exit(EXIT_FAILURE);
        }
        return items[frontIndex];
    }

    template <typename T>
    int Queue<T>::getSize() const {
        return size;
    }

    template <typename T>
    void Queue<T>::empty() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    template <typename T>
    bool Queue<T>::isEmpty() const {
        return size == 0;
    }

    template <typename T>
    void Queue<T>::print() const {
        if (isEmpty()) {
            std::cout << "Queue is empty.\n";
            return;
        }
        std::cout << "Queue elements: ";
        size_t index = frontIndex;
        for (size_t i = 0; i < size; ++i) {
            std::cout << items[index] << " ";
            index = (index + 1) % MAX_SIZE;
        }
        std::cout << "\n";
    }
}
